

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const universal = {
  "ssr": false
};
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.DyTCQZnK.js","_app/immutable/chunks/Dp1pzeXC.js","_app/immutable/chunks/CwAGPVxN.js","_app/immutable/chunks/C5AzslXh.js","_app/immutable/chunks/CbcjTrhg.js"];
export const stylesheets = ["_app/immutable/assets/weather-themes.C0FDgLwf.css","_app/immutable/assets/0.CXRJX7k5.css"];
export const fonts = [];
