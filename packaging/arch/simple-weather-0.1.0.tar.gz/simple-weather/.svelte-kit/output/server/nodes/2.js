

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.BEYexi2n.js","_app/immutable/chunks/CwAGPVxN.js","_app/immutable/chunks/C5AzslXh.js","_app/immutable/chunks/CbcjTrhg.js","_app/immutable/chunks/Dto5IpV7.js","_app/immutable/chunks/C-4kgw_r.js"];
export const stylesheets = ["_app/immutable/assets/weather-themes.C0FDgLwf.css","_app/immutable/assets/2.DXHpfaVO.css"];
export const fonts = [];
