

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.Om0qK_Wm.js","_app/immutable/chunks/CwAGPVxN.js","_app/immutable/chunks/C5AzslXh.js","_app/immutable/chunks/Dto5IpV7.js","_app/immutable/chunks/C6IqZhWN.js"];
export const stylesheets = [];
export const fonts = [];
