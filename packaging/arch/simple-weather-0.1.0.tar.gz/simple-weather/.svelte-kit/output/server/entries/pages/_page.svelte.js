import { a1 as attr, a2 as ensure_array_like, e as escape_html, a3 as attr_style, a4 as attr_class, a5 as stringify, s as slot, a6 as bind_props, a7 as fallback } from "../../chunks/renderer.js";
import { w as writable } from "../../chunks/index.js";
/* empty css                          */
const defaultSettings = {
  tempUnit: "C",
  speedUnit: "km/h",
  defaultCity: null
};
const stored = typeof localStorage !== "undefined" ? localStorage.getItem("simple_weather_settings") : null;
const initial = stored ? JSON.parse(stored) : defaultSettings;
const settings = writable(initial);
settings.subscribe((value) => {
  if (typeof localStorage !== "undefined") {
    localStorage.setItem("simple_weather_settings", JSON.stringify(value));
  }
});
function CitySearch($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let query = "";
    let results = [];
    let isSearching = false;
    $$renderer2.push(`<div class="search-container svelte-1otzt7l"><input type="text" class="glass-panel search-input glass-text app-interactive svelte-1otzt7l" placeholder="Search city..."${attr("value", query)}/> `);
    if (results.length > 0 || isSearching) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="glass-panel results-dropdown svelte-1otzt7l">`);
      {
        $$renderer2.push("<!--[-1-->");
        $$renderer2.push(`<!--[-->`);
        const each_array = ensure_array_like(results);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let result = each_array[$$index];
          $$renderer2.push(`<button class="dropdown-item svelte-1otzt7l"><span class="city-name glass-text svelte-1otzt7l">${escape_html(result.name)}</span> <span class="city-detail glass-text-secondary svelte-1otzt7l">`);
          if (result.admin1) {
            $$renderer2.push("<!--[0-->");
            $$renderer2.push(`${escape_html(result.admin1)},`);
          } else {
            $$renderer2.push("<!--[-1-->");
          }
          $$renderer2.push(`<!--]-->${escape_html(result.country)}</span></button>`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
function parseLocalHour(isoStr) {
  if (!isoStr) return 6;
  const timePart = isoStr.split("T")[1];
  if (!timePart) return 6;
  const [hours, minutes] = timePart.split(":");
  return parseInt(hours, 10) + parseInt(minutes, 10) / 60;
}
function getPhase(hour, sr, ss) {
  if (hour >= sr - 2.25 && hour < sr - 0.75) return "pre-dawn";
  if (hour >= sr - 0.75 && hour < sr + 0.75) return "sunrise";
  if (hour >= sr + 0.75 && hour < 11.5) return "morning";
  if (hour >= 11.5 && hour < 14) return "noon";
  if (hour >= 14 && hour < ss - 2.25) return "afternoon";
  if (hour >= ss - 2.25 && hour < ss - 0.75) return "late-afternoon";
  if (hour >= ss - 0.75 && hour < ss + 0.75) return "sunset";
  if (hour >= ss + 0.75 && hour < ss + 2.25) return "dusk";
  return "night";
}
function useDayCycle(sunriseStr, sunsetStr, utcOffsetSeconds) {
  const store = writable({
    phase: "noon",
    sunPosition: { x: 50, y: 100 },
    moonPosition: { x: 50, y: 100 },
    starOpacity: 0
  });
  function tick() {
    const utcNow = Date.now();
    const targetNow = utcNow + utcOffsetSeconds * 1e3;
    const date = new Date(targetNow);
    const hour = date.getUTCHours() + date.getUTCMinutes() / 60;
    const sr = parseLocalHour(sunriseStr);
    const ss = parseLocalHour(sunsetStr);
    const phase = getPhase(hour, sr, ss);
    let sunProgress = (hour - sr) / (ss - sr);
    sunProgress = Math.max(0, Math.min(1, sunProgress));
    const sunAngle = sunProgress * Math.PI;
    const sunX = 15 + sunProgress * 70;
    const sunY = 85 - Math.sin(sunAngle) * 72;
    const moonHour = hour < sr ? hour + 24 : hour;
    const moonDuration = sr + 24 - ss;
    let moonProgress = (moonHour - ss) / moonDuration;
    moonProgress = Math.max(0, Math.min(1, moonProgress));
    const moonAngle = moonProgress * Math.PI;
    const moonX = 15 + moonProgress * 70;
    const moonY = 85 - Math.sin(moonAngle) * 72;
    let starOpacity = 0;
    if (phase === "night") starOpacity = 1;
    else if (phase === "dusk") starOpacity = 0.6;
    else if (phase === "pre-dawn") starOpacity = 0.4;
    store.set({
      phase,
      sunPosition: { x: sunX, y: sunY },
      moonPosition: { x: moonX, y: moonY },
      starOpacity
    });
  }
  tick();
  const interval = setInterval(tick, 6e4);
  return { store, cleanup: () => clearInterval(interval) };
}
function getComposedOverrides(phase, weather) {
  let filterStr = null;
  let glassBlurOffset = 0;
  let moonOpacity = 1;
  if (weather === "fog") {
    glassBlurOffset = -4;
  }
  if (weather === "heavy-rain" && (phase === "sunset" || phase === "dusk")) {
    filterStr = "brightness(0.75) saturate(0.8)";
  }
  const isNightPhase = ["night", "pre-dawn", "dusk"].includes(phase);
  if (!isNightPhase) {
    moonOpacity = 0;
  } else if (weather !== "clear-night") {
    moonOpacity = 0.2;
  } else {
    moonOpacity = 1;
  }
  return { filterStr, glassBlurOffset, moonOpacity };
}
function WeatherBackground($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let overrides, numClouds, isNighttime, cloudType, numFogBands, rainDrops, snowFlakes, dustMotes, dynamicVars;
    let state = $$props["state"];
    let season = $$props["season"];
    let sunriseStr = $$props["sunriseStr"];
    let sunsetStr = $$props["sunsetStr"];
    let utcOffsetSeconds = fallback($$props["utcOffsetSeconds"], 0);
    let phase = "noon";
    let cleanup = null;
    let sunX = 50;
    let sunY = 100;
    let moonX = 50;
    let moonY = 100;
    let starOpacity = 0;
    function randomStyle(type, index = 0) {
      const left = Math.random() * 100;
      let top = -10;
      if (type === "cloud") top = -10 + Math.random() * 85;
      else if (type === "fog") top = 30 + Math.random() * 70;
      else if (type === "star") top = Math.random() * 100;
      const delay = Math.random() * -25;
      let duration = 10;
      if (type === "cloud") duration = 25 + Math.random() * 20;
      else if (type === "fog") duration = 30 + Math.random() * 20;
      else if (type === "rain") duration = 0.6 + Math.random() * 0.8;
      else if (type === "snow") duration = 3 + Math.random() * 5;
      else if (type === "star") duration = 2 + Math.random() * 4;
      else if (type === "dust") duration = 10 + Math.random() * 15;
      const zIndex = type === "cloud" ? index < numClouds * 0.4 ? 1 : 0 : 0;
      const baseSize = type === "cloud" ? 120 + Math.random() * 200 : 0;
      let opacity = 1;
      if (type === "cloud") opacity = zIndex === 1 ? 0.95 : 0.75;
      else if (type === "star") opacity = starOpacity;
      let size = baseSize;
      if (type === "snow") size = 3 + Math.random() * 5;
      else if (type === "star") size = 1 + Math.random() * 2;
      else if (type === "dust") size = 1 + Math.random() * 3;
      else if (type === "rain") size = 2 + Math.random() * 2;
      const width = type === "fog" ? 100 + Math.random() * 50 : size;
      const height = type === "cloud" ? size / 3 : type === "fog" ? 15 + Math.random() * 10 : size;
      let style = `left: ${left}%; top: ${top}%; animation-delay: ${delay}s; animation-duration: ${duration}s; width: ${width}px; height: ${height}px; opacity: ${opacity}; z-index: ${zIndex};`;
      if (type === "rain") style += ` width: ${size * 1.5}px; height: ${size * 12}px;`;
      return style;
    }
    {
      if (cleanup) cleanup();
      if (sunriseStr && sunsetStr) {
        const cycle = useDayCycle(sunriseStr, sunsetStr, utcOffsetSeconds);
        cleanup = cycle.cleanup;
        cycle.store.subscribe((data) => {
          phase = data.phase;
          sunX = data.sunPosition.x;
          sunY = data.sunPosition.y;
          moonX = data.moonPosition.x;
          moonY = data.moonPosition.y;
          starOpacity = data.starOpacity;
        });
      }
    }
    overrides = getComposedOverrides(phase, state);
    numClouds = state === "partly-cloudy" ? 15 : state === "cloudy" || state === "overcast" ? 35 : state.includes("rain") || state === "thunderstorm" ? 25 : 0;
    isNighttime = ["night", "pre-dawn", "dusk"].includes(phase);
    cloudType = state === "cloudy" || state === "overcast" || state.includes("rain") || state === "thunderstorm" || isNighttime ? "dark" : "light";
    numFogBands = state === "fog" ? 5 : 0;
    rainDrops = state.includes("rain") || state === "drizzle" || state === "thunderstorm" ? state === "heavy-rain" || state === "thunderstorm" ? 80 : state === "rain" ? 50 : 30 : 0;
    snowFlakes = state === "snow" || state === "blizzard" ? state === "blizzard" ? 100 : 60 : 0;
    dustMotes = state === "dust" ? 40 : 0;
    dynamicVars = `
    --sun-x: ${sunX}vw; --sun-y: ${sunY}vh;
    --moon-x: ${moonX}vw; --moon-y: ${moonY}vh;
    --moon-opacity: ${overrides.moonOpacity};
    --star-opacity: ${starOpacity};
    ${overrides.filterStr ? `--cycle-filter: ${overrides.filterStr};` : ""}
  `;
    $$renderer2.push(`<div class="sky-bg svelte-cn6e54"${attr("data-weather", state)}${attr("data-season", season)}${attr("data-time", phase)}${attr_style(dynamicVars)}><div class="celestial-body sun"></div> <div class="celestial-body moon"></div> `);
    if (state === "overcast") {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="particle-layer overcast-veil svelte-cn6e54"></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (numClouds > 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="particle-layer clouds"><!--[-->`);
      const each_array = ensure_array_like(Array(numClouds));
      for (let i = 0, $$length = each_array.length; i < $$length; i++) {
        each_array[i];
        $$renderer2.push(`<div${attr_class("particle cloud", void 0, {
          "dark-cloud": cloudType === "dark",
          "light-cloud": cloudType === "light"
        })}${attr_style(randomStyle("cloud", i))}><div class="cloud-bubble cb1"></div> <div class="cloud-bubble cb2"></div> <div class="cloud-bubble cb3"></div></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (numFogBands > 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="particle-layer fog"><!--[-->`);
      const each_array_1 = ensure_array_like(Array(numFogBands));
      for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
        each_array_1[$$index_1];
        $$renderer2.push(`<div class="particle fog-band"${attr_style(randomStyle("fog"))}></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> <div class="particle-layer stars"><!--[-->`);
    const each_array_2 = ensure_array_like(Array(60));
    for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
      each_array_2[$$index_2];
      $$renderer2.push(`<div class="particle star"${attr_style(randomStyle("star"))}></div>`);
    }
    $$renderer2.push(`<!--]--></div> `);
    if (rainDrops > 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="particle-layer rain"><!--[-->`);
      const each_array_3 = ensure_array_like(Array(rainDrops));
      for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
        each_array_3[$$index_3];
        $$renderer2.push(`<div class="particle rain-drop"${attr_style(randomStyle("rain"))}></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (snowFlakes > 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="particle-layer snow"><!--[-->`);
      const each_array_4 = ensure_array_like(Array(snowFlakes));
      for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
        each_array_4[$$index_4];
        $$renderer2.push(`<div class="particle snow-flake"${attr_style(randomStyle("snow"))}></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (dustMotes > 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="particle-layer dust"><!--[-->`);
      const each_array_5 = ensure_array_like(Array(dustMotes));
      for (let $$index_5 = 0, $$length = each_array_5.length; $$index_5 < $$length; $$index_5++) {
        each_array_5[$$index_5];
        $$renderer2.push(`<div class="particle dust-mote"${attr_style(randomStyle("dust"))}></div>`);
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (state === "thunderstorm") {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div class="thunder-flash"></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div> <div class="app-content-layer svelte-cn6e54"${attr_style(`--glass-blur-offset: ${stringify(overrides.glassBlurOffset)}px`)}><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { state, season, sunriseStr, sunsetStr, utcOffsetSeconds });
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let currentState = "clear-day";
    let currentSeason = "Summer";
    let currentSunrise = new Date((/* @__PURE__ */ new Date()).setHours(6, 0, 0, 0)).toISOString();
    let currentSunset = new Date((/* @__PURE__ */ new Date()).setHours(18, 0, 0, 0)).toISOString();
    let currentUtcOffset = 0;
    $$renderer2.push(`<main id="app"${attr("data-weather", currentState)} style="background: transparent !important;" class="svelte-1uha8ag">`);
    WeatherBackground($$renderer2, {
      state: currentState,
      season: currentSeason,
      sunriseStr: currentSunrise,
      sunsetStr: currentSunset,
      utcOffsetSeconds: currentUtcOffset,
      children: ($$renderer3) => {
        $$renderer3.push(`<div class="app-window svelte-1uha8ag"><header class="top-bar svelte-1uha8ag"><div class="left-spacer svelte-1uha8ag"></div> <div class="search-wrapper svelte-1uha8ag">`);
        CitySearch($$renderer3);
        $$renderer3.push(`<!----></div> <div class="action-buttons svelte-1uha8ag"><button class="icon-btn glass-panel glass-text app-interactive svelte-1uha8ag" title="Refresh Weather"><svg style="flex-shrink: 0; pointer-events: none;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="24" height="24" class="svelte-1uha8ag"><path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" class="svelte-1uha8ag"></path></svg></button> <button class="icon-btn glass-panel glass-text app-interactive svelte-1uha8ag" title="Settings"><svg style="flex-shrink: 0; pointer-events: none;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svelte-1uha8ag"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" class="svelte-1uha8ag"></path><circle cx="12" cy="12" r="3" class="svelte-1uha8ag"></circle></svg></button></div></header> <div class="dashboard-grid svelte-1uha8ag"><div class="column left-col svelte-1uha8ag">`);
        {
          $$renderer3.push("<!--[0-->");
          $$renderer3.push(`<div class="glass-card skeleton-card skeleton-shimmer svelte-1uha8ag"></div>`);
        }
        $$renderer3.push(`<!--]--></div> <div class="column right-col svelte-1uha8ag">`);
        {
          $$renderer3.push("<!--[-1-->");
          $$renderer3.push(`<div class="glass-panel skeleton-strip skeleton-shimmer svelte-1uha8ag"></div> <div class="glass-panel skeleton-chart skeleton-shimmer svelte-1uha8ag"></div>`);
        }
        $$renderer3.push(`<!--]--></div></div></div>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></main>`);
  });
}
export {
  _page as default
};
