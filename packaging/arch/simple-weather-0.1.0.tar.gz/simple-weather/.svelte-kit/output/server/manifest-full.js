export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","svelte.svg","tauri.svg","vite.svg"]),
	mimeTypes: {".png":"image/png",".svg":"image/svg+xml"},
	_: {
		client: {start:"_app/immutable/entry/start.CVhczPpa.js",app:"_app/immutable/entry/app.CRfHeIJ0.js",imports:["_app/immutable/entry/start.CVhczPpa.js","_app/immutable/chunks/C6IqZhWN.js","_app/immutable/chunks/C5AzslXh.js","_app/immutable/entry/app.CRfHeIJ0.js","_app/immutable/chunks/Dp1pzeXC.js","_app/immutable/chunks/C5AzslXh.js","_app/immutable/chunks/Dto5IpV7.js","_app/immutable/chunks/CwAGPVxN.js","_app/immutable/chunks/C-4kgw_r.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
